package com.metacube.get2019.service;

import com.metacube.get2019.model.dto.Pass;
import com.metacube.get2019.model.dto.SignUpForm;
import com.metacube.get2019.model.dto.VehicleForm;
import com.metacube.get2019.model.pojo.Employee;
import com.metacube.get2019.model.pojo.Vehicle;

public interface ParkingService {


	boolean validateEmployee(String email, String password);
	Employee getEmployee(String email);
	boolean addEmployee(Employee employee);
	boolean addVehicle(VehicleForm vehicleform);
	boolean addPass(Pass pass);
	Vehicle getVehicle(int id);
	Pass getPass(int id);
	boolean updateEmployee(Employee employee);

}
