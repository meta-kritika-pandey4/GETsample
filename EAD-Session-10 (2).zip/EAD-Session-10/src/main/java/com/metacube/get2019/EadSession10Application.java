package com.metacube.get2019;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EadSession10Application {

	public static void main(String[] args) {
		SpringApplication.run(EadSession10Application.class, args);
	}

}
