package com.metacube.get2019.dao;

import com.metacube.get2019.model.pojo.User;

public interface UserDao {
	public boolean add(User user);
}
