package com.metacube.get2019.dao;

import com.metacube.get2019.model.dto.Pass;
import com.metacube.get2019.model.dto.VehicleForm;
import com.metacube.get2019.model.pojo.Employee;
import com.metacube.get2019.model.pojo.Vehicle;

public interface ParkingDao {
	boolean validateEmployee(String email, String password);
	public Employee getEmployee(String email);
	public boolean addEmployee(Employee employee);
	boolean addVehicle(VehicleForm vehicleform);
	boolean addPass(Pass pass);
	Vehicle getVehicle(int id);
	Pass getPass(int id);
	boolean updateEmployee(Employee employee);
}
